//4006895   Jul 3, 2013 6:00:13 PM	fuwutu	 50A - Domino piling	 GNU C++0x	Accepted	15 ms	0 KB
#include <iostream>

using namespace std;

int main()
{
    int M, N;
    cin >> M >> N;
    cout << M * N / 2 << endl;
    return 0;
}
