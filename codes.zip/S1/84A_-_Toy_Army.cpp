//4033542   Jul 7, 2013 11:18:30 AM	fuwutu	 84A - Toy Army	 GNU C++0x	Accepted	15 ms	0 KB
#include <iostream>

using namespace std;

int main()
{
    int n;
    cin >> n;
    cout << n + n / 2 << endl;
    return 0;
}
